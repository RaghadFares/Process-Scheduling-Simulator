
package os;
import java.util.*;

class Process {
    int id, arrivalTime, burstTime, remainingTime, completionTime, waitingTime, turnaroundTime;
    
    public Process(int id, int arrivalTime, int burstTime) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
        this.remainingTime = burstTime;
    }
}

public class ProcessScheduler {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();
        
        List<Process> processes = new ArrayList<>();
        System.out.println("\nProcesses details:");
        for (int i = 0; i < n; i++) {
            System.out.print("P" + (i+1) + ": Arrival time= , Burst time= ");
            int arrivalTime = sc.nextInt();
            int burstTime = sc.nextInt();
            processes.add(new Process(i+1, arrivalTime, burstTime));
        }
        
        System.out.println("\nNumber of processes= " + n + " (" + getProcessList(processes) + ")");
        System.out.println("Arrival times and burst times as follows:");
        for (Process p : processes) {
            System.out.printf("P%d: Arrival time = %d, Burst time = %d ms%n", p.id, p.arrivalTime, p.burstTime);
        }
        
        System.out.println("\nScheduling Algorithm: Shortest remaining time first");
        System.out.println("Context Switch: 1 ms\n");
        scheduleProcesses(processes);
    }
    
    private static String getProcessList(List<Process> processes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < processes.size(); i++) {
            sb.append("P").append(processes.get(i).id);
            if (i != processes.size() - 1) {
                sb.append(", ");
            }
        }
        return sb.toString();
    }
    
    public static void scheduleProcesses(List<Process> processes) {
        int currentTime = 0, completed = 0;
        int totalWaitingTime = 0, totalTurnaroundTime = 0;
        int totalExecutionTime = 0;
        int idleTime = 0;
        double cpuUtilization;
        List<String> ganttChart = new ArrayList<>();
        
        PriorityQueue<Process> pq = new PriorityQueue<>(
            (a, b) -> a.remainingTime == b.remainingTime ? a.arrivalTime - b.arrivalTime : a.remainingTime - b.remainingTime);
        
        processes.sort(Comparator.comparingInt(p -> p.arrivalTime));
        
        int index = 0;
        Process currentProcess = null;
        while (completed < processes.size()) {
            while (index < processes.size() && processes.get(index).arrivalTime <= currentTime) {
                pq.add(processes.get(index++));
            }
            
            if (!pq.isEmpty()) {
                Process p = pq.poll();
                if (currentProcess != p && currentProcess != null) {
                    ganttChart.add(currentTime + "-" + (currentTime + 1) + "  CS"); // Context Switch
                    currentTime++;
                    totalExecutionTime++; // Context switch adds to execution time
                }
                currentProcess = p;
                
                int startTime = currentTime;
                int executionTime = Math.min(p.remainingTime, (index < processes.size() ? processes.get(index).arrivalTime - currentTime : p.remainingTime));
                currentTime += executionTime;
                totalExecutionTime += executionTime;
                p.remainingTime -= executionTime;
                ganttChart.add(startTime + "-" + currentTime + "  P" + p.id);
                
                if (p.remainingTime == 0) {
                    p.completionTime = currentTime;
                    p.turnaroundTime = p.completionTime - p.arrivalTime;
                    p.waitingTime = p.turnaroundTime - p.burstTime;
                    totalWaitingTime += p.waitingTime;
                    totalTurnaroundTime += p.turnaroundTime;
                    completed++;
                } else {
                    pq.add(p);
                }
            } else {
                ganttChart.add(currentTime + "-" + (currentTime + 1) + "  IDLE");
                idleTime++;
                currentTime++;
            }
        }
        
        cpuUtilization = ((double) (totalExecutionTime) / (totalExecutionTime + idleTime)) * 100;
        
        System.out.println("Time    Process/CS");
        for (String entry : ganttChart) {
            System.out.println(entry);
        }
        System.out.println("\nPerformance Metrics");
        System.out.printf("Average Turnaround Time: %.2f\n", (double) totalTurnaroundTime / processes.size());
        System.out.printf("Average Waiting Time: %.2f\n", (double) totalWaitingTime / processes.size());
        System.out.printf("CPU Utilization: %.2f%%\n", cpuUtilization);
    }
}
